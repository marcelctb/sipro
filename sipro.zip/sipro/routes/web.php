<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => ['auth'], 'namespace' => 'Admin'], function(){    
    Route::get('admin', 'AdminController@index')->name('admin.home');

    /* perfil */
    Route::any('profile.search', 'UserController@search')->name('profile.search');

    Route::get('profile', 'UserController@index')->name('profile.index');
    Route::get('profile/create', 'UserController@create')->name('profile.create');
    Route::post('profile', 'UserController@store')->name('profile.store');
    Route::get('profile/{id}/edit', 'UserController@edit')->name('profile.edit');
    Route::put('profile/{id}', 'UserController@update')->name('profile.update');    
    Route::delete('profile/{id}', 'UserController@destroy')->name('profile.destroy');
    /* perfil */

    /* paciente */
    Route::any('paciente.search', 'PacienteController@search')->name('paciente.search');

    Route::get('paciente', 'PacienteController@index')->name('paciente.index');
    Route::get('paciente/create', 'PacienteController@create')->name('paciente.create');
    Route::post('paciente', 'PacienteController@store')->name('paciente.store');
    Route::get('paciente/{id}/edit', 'PacienteController@edit')->name('paciente.edit');
    Route::put('paciente/{id}', 'PacienteController@update')->name('paciente.update');    
    Route::delete('paciente/{id}', 'PacienteController@destroy')->name('paciente.destroy');
    /* paciente */
    
    /* identificacao */
    Route::any('identificacao.searchPaciente', 'IdentificacaoController@searchPaciente')->name('identificacao.searchPaciente');
    Route::get('identificacao.sucesso', 'IdentificacaoController@sucesso')->name('identificacao.sucesso');
    Route::any('identificacao.search', 'IdentificacaoController@search')->name('identificacao.search');
    Route::get('identificacao.iniciarTeste/{id}', 'IdentificacaoController@iniciarTeste')->name('identificacao.iniciarTeste');    
    
    Route::get('identificacao/{id}', 'IdentificacaoController@index')->name('identificacao.index');
    Route::get('identificacao/{id}/{emocao}/edit', 'IdentificacaoController@edit')->name('identificacao.edit');
    Route::put('identificacao/{id}/{emocao}', 'IdentificacaoController@update')->name('identificacao.update');
    Route::get('identificacao.list', 'IdentificacaoController@list')->name('identificacao.list');

        /* introducao */
        Route::any('identificacao.introducao/{id}/{pg}/{emocao}', 'IdentificacaoController@introducao')->name('identificacao.introducao');
        Route::put('identificacao.updateIntroducao/{id}/{pg}/{emocao}', 'IdentificacaoController@updateIntroducao')->name('identificacao.updateIntroducao');
        /* introducao */

        /* emocao */
        Route::any('identificacao.emocao/{id}/{pg}/{emocao}/{pergunta}', 'IdentificacaoController@emocao')->name('identificacao.emocao');
        Route::put('identificacao.updateEmocao/{id}/{pg}/{emocao}/{pergunta}', 'IdentificacaoController@updateEmocao')->name('identificacao.updateEmocao');
        /* emocao */
    /* identificacao */

    /* producao */
    Route::any('producao.searchPaciente', 'ProducaoController@searchPaciente')->name('producao.searchPaciente');
    Route::get('producao.sucesso', 'ProducaoController@sucesso')->name('producao.sucesso');
    Route::any('producao.search', 'ProducaoController@search')->name('producao.search');
    Route::get('producao.iniciarTeste/{id}', 'ProducaoController@iniciarTeste')->name('producao.iniciarTeste');
    Route::get('producao.confirmacao/{id}', 'ProducaoController@confirmacao')->name('producao.confirmacao');
    Route::put('producao.updateIntro/{id}', 'ProducaoController@updateIntro')->name('producao.updateIntro');
    Route::post('producao.storeProducaoProbabilidade', 'ProducaoController@storeProducaoProbabilidade')->name('producao.storeProducaoProbabilidade');

    Route::get('producao/{id}', 'ProducaoController@index')->name('producao.index');
    Route::get('producao/{id}/{emocao}/edit', 'ProducaoController@edit')->name('producao.edit');
    Route::put('producao/{id}/{emocao}', 'ProducaoController@update')->name('producao.update');
    Route::get('producao.list', 'ProducaoController@list')->name('producao.list');
    /* producao */
});

Route::get('/', 'Site\SiteController@index')->name('home');

Auth::routes();