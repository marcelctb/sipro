# Facial Emotion Training Tool for Schizophrenia

This repository contains the source code of a web-based computational application developed for the study presented in the paper submitted to ICEIS. The application was designed to support training in social cognition, focusing on the recognition and production of facial emotional expressions in individuals diagnosed with schizophrenia.

## Purpose of the Application

The main goal of the application is to assist patients with schizophrenia in developing skills related to facial emotion processing by:

- Training the recognition of basic facial emotions from static images
- Training the production of facial emotional expressions using real-time webcam input
- Providing clear instructions and simplified interaction, tailored to cognitive and usability needs
- Supporting clinical and research activities related to social cognition rehabilitation

The tool is intended exclusively for educational and research purposes, and not as a diagnostic system.

## Scope of the Application

The application includes the following core features:

- A facial emotion identification module, where users classify facial images according to basic emotions
- A facial emotion production module, where users attempt to reproduce a target emotion using their own facial expressions
- Support for the six basic emotions proposed by Ekman and Friesen: joy, sadness, anger, fear, disgust, and surprise
- Performance tracking based on accuracy and execution time
- Generation of reports to support preliminary analysis and clinical evaluation

The system was developed for the web environment, using:

- PHP (Laravel framework)
- MySQL database
- JavaScript for client-side interaction
- Webcam-based facial capture for the production module

## Important Note on Facial Analysis Library

Files related to the Affectiva (Affdex) JavaScript SDK are not included in this repository.

At the time of the system’s development and evaluation, the facial expression analysis functionality relied on a third-party proprietary JavaScript library that was obtained directly from the provider under an evaluation license.

Due to subsequent changes in the provider’s licensing and distribution model, the original SDK cannot be redistributed publicly. For this reason:

- All files associated with the Affectiva/Affdex library were intentionally removed from this repository
- This repository contains only the original application code, excluding third-party proprietary components

Researchers interested in reproducing or extending the production module must integrate an alternative facial expression analysis library that complies with their own licensing requirements.

## Reproducibility and Extensions

The source code is made publicly available to promote transparency, methodological clarity, and scientific reproducibility, within the constraints imposed by third-party licensing.

This repository may serve as a baseline for:

- Developing alternative facial emotion analysis pipelines
- Integrating open-source computer vision or machine learning libraries
- Extending the tool for other clinical or educational contexts
- Conducting usability or exploratory studies in social cognition

## License

This project is licensed under the MIT License. See the LICENSE file for details.
