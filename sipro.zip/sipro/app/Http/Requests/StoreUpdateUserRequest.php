<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUpdateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $id = $this->segment(2);

        return [
            'name' => 'required|min:3|max:255',
            'email' => "required|min:3|max:100|unique:users,email,{$id},id",
            'password' => 'required|min:6|max:255',
            'type' => 'required',
        ];
    }

    public function messages(){
        return [
            'name.required' => 'Nome é obrigatório',
            'email.required' => 'E-mail é obrigatório',
            'password.required' => 'Senha é obrigatória',
            'type.required' => 'Tipo é obrigatório',
        ];
    }
}
