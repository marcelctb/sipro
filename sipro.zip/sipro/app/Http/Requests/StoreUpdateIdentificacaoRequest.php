<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUpdateIdentificacaoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $pg = $this->segment(3);
        $emocao = $this->segment(4);
        
        return [
            'resposta' => 'required',
        ];        
    }

    public function messages(){
        $pg = $this->segment(3);
        $emocao = $this->segment(4);
        
        return [
            'resposta.required' => 'Selecione uma das opções disponíveis',
        ];           
    }
}
