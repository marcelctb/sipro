<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUpdatePacienteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nome' => 'required|min:3|max:255',
            'data_nasc' => 'required',
            'sexo' => 'required',
            'com_esquizofrenia' => 'required',
        ];
    }

    public function messages(){
        return [
            'nome.required' => 'Nome é obrigatório',
            'data_nasc.required' => 'Data Nasc. é obrigatória',
            'sexo.required' => 'Sexo é obrigatório',
            'com_esquizofrenia.required' => 'Pessoa com Esquizofrenia é obrigatório',
        ];
    }    
}
