<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\StoreUpdateIdentificacaoRequest;
use App\Http\Controllers\Controller;
use App\Models\Paciente;
use App\Models\Emocao;
use App\Models\Identificacao;
use Carbon\Carbon;

class IdentificacaoController extends Controller
{
    //
    public function edit($id, $emocao){

        $identificacao = Identificacao::where('id', $id)->first();
        if(!$identificacao)
            return redirect()->back();

        $paciente = Paciente::where('id', $identificacao->paciente_id)->first();

        $descricaoEmocao = Emocao::where('id', $emocao)->first();

        $listaEmocoes = Emocao::inRandomOrder()->get();
        
        //imagem            
            if($descricaoEmocao->descricao == 'tristeza'){
                $numeroArquivo = rand(1, 14);
            }elseif($descricaoEmocao->descricao == 'alegria'){
                $numeroArquivo = rand(1, 40);
            }elseif($descricaoEmocao->descricao == 'raiva'){
                $numeroArquivo = rand(1, 14);
            }elseif($descricaoEmocao->descricao == 'nojo'){
                $numeroArquivo = rand(1, 21);
            }elseif($descricaoEmocao->descricao == 'surpresa'){
                $numeroArquivo = rand(1, 18);
            }elseif($descricaoEmocao->descricao == 'medo'){
                $numeroArquivo = rand(1, 13);
            }
        //
        
        return view ('admin.identificacao.edit',[
            'identificacao' => $identificacao,
            'paciente' => $paciente,
            'emocao' => $emocao,
            'descricaoEmocao' => $descricaoEmocao,
            'numeroArquivo' => $numeroArquivo,
            'listaEmocoes' => $listaEmocoes
        ]);
    }

    public function update(StoreUpdateIdentificacaoRequest $request, $id, $emocao){

        $identificacao = Identificacao::where('id', $id)->first();

        if(!$identificacao)
            return redirect()->back();

        $data = $request->except('_method', '_token');
        foreach($data as $key => $value){
            $nameEmocao = $key;
            $valorEmocao = $value;
        }

        if($nameEmocao == 'tristeza'){
            if($valorEmocao == $emocao){
                $identificacao['tristeza'] = 100;
            }else{
                $identificacao['tristeza'] = 0;
            }
        }elseif($nameEmocao == 'alegria'){
            if($valorEmocao == $emocao){
                $identificacao['alegria'] = 100;
            }else{
                $identificacao['alegria'] = 0;
            }
        }elseif($nameEmocao == 'raiva'){
            if($valorEmocao == $emocao){
                $identificacao['raiva'] = 100;
            }else{
                $identificacao['raiva'] = 0;
            }
        }elseif($nameEmocao == 'nojo'){
            if($valorEmocao == $emocao){
                $identificacao['nojo'] = 100;
            }else{
                $identificacao['nojo'] = 0;
            }
        }elseif($nameEmocao == 'surpresa'){
            if($valorEmocao == $emocao){
                $identificacao['surpresa'] = 100;
            }else{
                $identificacao['surpresa'] = 0;
            }
        }elseif($nameEmocao == 'medo'){
            if($valorEmocao == $emocao){
                $identificacao['medo'] = 100;
            }else{
                $identificacao['medo'] = 0;
            }
        }

        $identificacao->save();

        return redirect()
                    ->route('identificacao.sucesso');
    }

    public function index($id, Paciente $paciente){
        if($id == 0){
            $pacientes = null;
        }else{
            $dataForm = ["id" => $id];
            $pacientes = $paciente->searchPacienteIdentificacao($dataForm);
        }
        
        return view ('admin.identificacao.index', compact('pacientes'));
    }

    public function search(Request $request, Identificacao $identificacao){
        $dataForm = $request->except('_token');

        $identificacoes = $identificacao->search($dataForm);

        return view ('admin.identificacao.list', compact('identificacoes', 'dataForm'));
    }

    public function list(){
        $identificacoes = Identificacao::paginate(10);
        
        return view ('admin.identificacao.list', compact('identificacoes'));
    }

    public function sucesso(){
        return view ('admin.identificacao.sucesso');
    }

    public function searchPaciente(Request $request, Paciente $paciente){
        $dataForm = $request->except('_token');

        $pacientes = $paciente->searchPacienteIdentificacao($dataForm);

        return view ('admin.identificacao.index', compact('pacientes', 'dataForm'));
    }

    public function iniciarTeste($id){
        $paciente = Paciente::where('id', $id)->first();
        if(!$paciente)
            return redirect()->back();

        if(!(is_null(Identificacao::where('paciente_id', $id)->first()))){
            $identificacao = Identificacao::where('ativo', 1)->where('paciente_id', $id)->first();
            $identificacao['ativo'] = 0;
            $identificacao->save();
        }

        Identificacao::create([
            'paciente_id' => $id,
            'ativo' => 1
        ]);

        return redirect()
                    ->route('identificacao.index', [$id]);
    }

    public function introducao($id, $pg, $emocao){

        //$identificacao = Identificacao::where('id', $id)->first();
        //if(!$identificacao)
        //    return redirect()->back();

        $paciente = Paciente::where('id', $id)->first();

        if($pg <= 15){
            $descritor = 'introducao';
        }else{
            $descritor = 'pergunta';
        }

        return view ('admin.identificacao._partials.introducao.'.$descritor.'',[
            //'identificacao' => $identificacao,
            'paciente' => $paciente,
            'pg' => $pg,
            'emocao' => $emocao
        ]);

    }

    public function updateIntroducao(StoreUpdateIdentificacaoRequest $request, $id, $pg, $emocao){
        //$identificacao = Identificacao::where('id', $id)->first();

        //if(!$identificacao)
        //    return redirect()->back();

        $data = $request->all();

        $identificacao = new Identificacao;

        if($data['resposta'] != 'N'){
            $identificacao['resposta'] = $data['resposta'];
        }

        $diaatual = Carbon::now();
        $time = $diaatual->toDateString()." ".$data['tempo'];
        
        $identificacao['paciente_id'] = $id;        
        $identificacao['emocao'] = $emocao;
        $identificacao['tempo'] = $time;
        
        $identificacao->save();

        if($pg <= 16){
            return redirect()
                        ->route('identificacao.introducao', [$id,$pg,$emocao]);
        }else{
            return redirect()
                        ->route('identificacao.sucesso');
        }
    }

    public function emocao($id, $pg, $emocao, $pergunta){

        $opcaoSim = null;
        $opcaoNao = null;
        $descricaoEmocao = null;
        $numeroArquivo = null;

        $paciente = Paciente::where('id', $id)->first();

        //array para gerar as perguntas aleatorias
        $input = str_replace(',', '', $pergunta);
        $arr = str_split($input);
        shuffle($arr);
        $emocaoTipo = $arr[0];

        if($emocao == 1){
            if($pg <= 9){
                $descritor = 'emocao';
                $descricaoEmocao = Emocao::where('id', $emocao)->first();
            }else{
                $descritor = 'pergunta';
                unset($arr[0]);
                $pergunta = implode(",", $arr);
    
                //imagem
                if($emocaoTipo == 'S'){
                    $opcaoSim = 100;
                    $opcaoNao = 0;
                    $descricaoEmocao = Emocao::where('id', $emocao)->first();                
                }elseif($emocaoTipo == 'N'){
                    $opcaoSim = 0;
                    $opcaoNao = 100;
                    $descricaoEmocao = Emocao::inRandomOrder()->where('id', '<>', $emocao)->first();
                }
    
                if($descricaoEmocao->descricao == 'tristeza'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'alegria'){
                    $numeroArquivo = rand(1, 40);
                }elseif($descricaoEmocao->descricao == 'raiva'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'nojo'){
                    $numeroArquivo = rand(1, 21);
                }elseif($descricaoEmocao->descricao == 'surpresa'){
                    $numeroArquivo = rand(1, 18);
                }elseif($descricaoEmocao->descricao == 'medo'){
                    $numeroArquivo = rand(1, 13);
                }
            }    
        }elseif($emocao == 2){
            if($pg <= 9){
                $descritor = 'emocao';
                $descricaoEmocao = Emocao::where('id', $emocao)->first();
            }else{
                $descritor = 'pergunta';
                unset($arr[0]);
                $pergunta = implode(",", $arr);
    
                //imagem
                if($emocaoTipo == 'S'){
                    $opcaoSim = 100;
                    $opcaoNao = 0;
                    $descricaoEmocao = Emocao::where('id', $emocao)->first();                
                }elseif($emocaoTipo == 'N'){
                    $opcaoSim = 0;
                    $opcaoNao = 100;
                    $descricaoEmocao = Emocao::inRandomOrder()->where('id', '<>', $emocao)->first();
                }
    
                if($descricaoEmocao->descricao == 'tristeza'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'alegria'){
                    $numeroArquivo = rand(1, 40);
                }elseif($descricaoEmocao->descricao == 'raiva'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'nojo'){
                    $numeroArquivo = rand(1, 21);
                }elseif($descricaoEmocao->descricao == 'surpresa'){
                    $numeroArquivo = rand(1, 18);
                }elseif($descricaoEmocao->descricao == 'medo'){
                    $numeroArquivo = rand(1, 13);
                }
            }    
        }elseif($emocao == 3){
            if($pg <= 10){
                $descritor = 'emocao';
                $descricaoEmocao = Emocao::where('id', $emocao)->first();
            }else{
                $descritor = 'pergunta';
                unset($arr[0]);
                $pergunta = implode(",", $arr);
    
                //imagem
                if($emocaoTipo == 'S'){
                    $opcaoSim = 100;
                    $opcaoNao = 0;
                    $descricaoEmocao = Emocao::where('id', $emocao)->first();                
                }elseif($emocaoTipo == 'N'){
                    $opcaoSim = 0;
                    $opcaoNao = 100;
                    $descricaoEmocao = Emocao::inRandomOrder()->where('id', '<>', $emocao)->first();
                }
    
                if($descricaoEmocao->descricao == 'tristeza'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'alegria'){
                    $numeroArquivo = rand(1, 40);
                }elseif($descricaoEmocao->descricao == 'raiva'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'nojo'){
                    $numeroArquivo = rand(1, 21);
                }elseif($descricaoEmocao->descricao == 'surpresa'){
                    $numeroArquivo = rand(1, 18);
                }elseif($descricaoEmocao->descricao == 'medo'){
                    $numeroArquivo = rand(1, 13);
                }
            }    
        }elseif($emocao == 4){
            if($pg <= 10){
                $descritor = 'emocao';
                $descricaoEmocao = Emocao::where('id', $emocao)->first();
            }else{
                $descritor = 'pergunta';
                unset($arr[0]);
                $pergunta = implode(",", $arr);
    
                //imagem
                if($emocaoTipo == 'S'){
                    $opcaoSim = 100;
                    $opcaoNao = 0;
                    $descricaoEmocao = Emocao::where('id', $emocao)->first();                
                }elseif($emocaoTipo == 'N'){
                    $opcaoSim = 0;
                    $opcaoNao = 100;
                    $descricaoEmocao = Emocao::inRandomOrder()->where('id', '<>', $emocao)->first();
                }
    
                if($descricaoEmocao->descricao == 'tristeza'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'alegria'){
                    $numeroArquivo = rand(1, 40);
                }elseif($descricaoEmocao->descricao == 'raiva'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'nojo'){
                    $numeroArquivo = rand(1, 21);
                }elseif($descricaoEmocao->descricao == 'surpresa'){
                    $numeroArquivo = rand(1, 18);
                }elseif($descricaoEmocao->descricao == 'medo'){
                    $numeroArquivo = rand(1, 13);
                }
            }    
        }elseif($emocao == 5){
            if($pg <= 9){
                $descritor = 'emocao';
                $descricaoEmocao = Emocao::where('id', $emocao)->first();
            }else{
                $descritor = 'pergunta';
                unset($arr[0]);
                $pergunta = implode(",", $arr);
    
                //imagem
                if($emocaoTipo == 'S'){
                    $opcaoSim = 100;
                    $opcaoNao = 0;
                    $descricaoEmocao = Emocao::where('id', $emocao)->first();                
                }elseif($emocaoTipo == 'N'){
                    $opcaoSim = 0;
                    $opcaoNao = 100;
                    $descricaoEmocao = Emocao::inRandomOrder()->where('id', '<>', $emocao)->first();
                }
    
                if($descricaoEmocao->descricao == 'tristeza'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'alegria'){
                    $numeroArquivo = rand(1, 40);
                }elseif($descricaoEmocao->descricao == 'raiva'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'nojo'){
                    $numeroArquivo = rand(1, 21);
                }elseif($descricaoEmocao->descricao == 'surpresa'){
                    $numeroArquivo = rand(1, 18);
                }elseif($descricaoEmocao->descricao == 'medo'){
                    $numeroArquivo = rand(1, 13);
                }
            }    
        }elseif($emocao == 6){
            if($pg <= 11){
                $descritor = 'emocao';
                $descricaoEmocao = Emocao::where('id', $emocao)->first();
            }else{
                $descritor = 'pergunta';
                unset($arr[0]);
                $pergunta = implode(",", $arr);
    
                //imagem
                if($emocaoTipo == 'S'){
                    $opcaoSim = 100;
                    $opcaoNao = 0;
                    $descricaoEmocao = Emocao::where('id', $emocao)->first();                
                }elseif($emocaoTipo == 'N'){
                    $opcaoSim = 0;
                    $opcaoNao = 100;
                    $descricaoEmocao = Emocao::inRandomOrder()->where('id', '<>', $emocao)->first();
                }
    
                if($descricaoEmocao->descricao == 'tristeza'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'alegria'){
                    $numeroArquivo = rand(1, 40);
                }elseif($descricaoEmocao->descricao == 'raiva'){
                    $numeroArquivo = rand(1, 14);
                }elseif($descricaoEmocao->descricao == 'nojo'){
                    $numeroArquivo = rand(1, 21);
                }elseif($descricaoEmocao->descricao == 'surpresa'){
                    $numeroArquivo = rand(1, 18);
                }elseif($descricaoEmocao->descricao == 'medo'){
                    $numeroArquivo = rand(1, 13);
                }
            }    
        }
        
        if($emocao == 1){
            if($pg == 12){
                $pergunta = '-';
            }
        }elseif($emocao == 2){
            if($pg == 12){
                $pergunta = '-';
            }
        }elseif($emocao == 3){
            if($pg == 13){
                $pergunta = '-';
            }
        }elseif($emocao == 4){
            if($pg == 13){
                $pergunta = '-';
            }
        }elseif($emocao == 5){
            if($pg == 12){
                $pergunta = '-';
            }
        }elseif($emocao == 6){
            if($pg == 14){
                $pergunta = '-';
            }
        }

        return view ('admin.identificacao._partials.emocao.'.$descritor.'',[
            //'identificacao' => $identificacao,
            'paciente' => $paciente,
            'pg' => $pg,
            'emocao' => $emocao,
            'pergunta' => $pergunta,
            'emocaoTipo' => $emocaoTipo,
            'descricaoEmocao' => $descricaoEmocao,
            'numeroArquivo' => $numeroArquivo,
            'opcaoSim' => $opcaoSim,
            'opcaoNao' => $opcaoNao
        ]);

    }

    public function updateEmocao(StoreUpdateIdentificacaoRequest $request, $id, $pg, $emocao, $pergunta){
        //$identificacao = Identificacao::where('id', $id)->first();

        //if(!$identificacao)
        //    return redirect()->back();

        $data = $request->all();

        $identificacao = new Identificacao;

        if($data['resposta'] != 'N'){
            $identificacao['resposta'] = $data['resposta'];
            $identificacao['tipo'] = $data['tipo'];
        }

        $diaatual = Carbon::now();
        $time = $diaatual->toDateString()." ".$data['tempo'];

        $identificacao['paciente_id'] = $id;
        $identificacao['emocao'] = $emocao;
        $identificacao['tempo'] = $time;

        $identificacao->save();

        if($emocao == 1){
            if($pg <= 12){
                return redirect()
                            ->route('identificacao.emocao', [$id,$pg,$emocao,$pergunta]);
            }else{
                return redirect()
                            ->route('identificacao.sucesso');
            }
        }elseif($emocao == 2){
            if($pg <= 12){
                return redirect()
                            ->route('identificacao.emocao', [$id,$pg,$emocao,$pergunta]);
            }else{
                return redirect()
                            ->route('identificacao.sucesso');
            }
        }elseif($emocao == 3){
            if($pg <= 13){
                return redirect()
                            ->route('identificacao.emocao', [$id,$pg,$emocao,$pergunta]);
            }else{
                return redirect()
                            ->route('identificacao.sucesso');
            }
        }elseif($emocao == 4){
            if($pg <= 13){
                return redirect()
                            ->route('identificacao.emocao', [$id,$pg,$emocao,$pergunta]);
            }else{
                return redirect()
                            ->route('identificacao.sucesso');
            }
        }elseif($emocao == 5){
            if($pg <= 12){
                return redirect()
                            ->route('identificacao.emocao', [$id,$pg,$emocao,$pergunta]);
            }else{
                return redirect()
                            ->route('identificacao.sucesso');
            }
        }elseif($emocao == 6){
            if($pg <= 14){
                return redirect()
                            ->route('identificacao.emocao', [$id,$pg,$emocao,$pergunta]);
            }else{
                return redirect()
                            ->route('identificacao.sucesso');
            }
        }
    }
}
