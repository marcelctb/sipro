<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\StoreUpdateProducaoRequest;
use App\Http\Controllers\Controller;
use App\Models\Paciente;
use App\Models\Emocao;
use App\Models\Producao;
use App\Models\ProducaoProbabilidade;

class ProducaoController extends Controller
{
    //
    public function edit($id, $emocao){

        //$producao = Producao::where('id', $id)->first();
        //if(!$producao)
        //    return redirect()->back();

        $novoproducao = new Producao;
        $novoproducao['paciente_id'] = $id;
        $novoproducao['emocao'] = $emocao;
        $novoproducao->save();

        $producao = Producao::where('paciente_id', $id)
                            ->where('emocao', $emocao)
                            ->orderBy('id', 'desc')
                            ->first();

        $paciente = Paciente::where('id', $id)->first();

        $descricaoEmocao = Emocao::where('id', $emocao)->first();

        //imagem            
        if($descricaoEmocao->descricao == 'tristeza'){
            $numeroArquivo = rand(1, 14);
        }elseif($descricaoEmocao->descricao == 'alegria'){
            $numeroArquivo = rand(1, 40);
        }elseif($descricaoEmocao->descricao == 'raiva'){
            $numeroArquivo = rand(1, 14);
        }elseif($descricaoEmocao->descricao == 'nojo'){
            $numeroArquivo = rand(1, 21);
        }elseif($descricaoEmocao->descricao == 'surpresa'){
            $numeroArquivo = rand(1, 18);
        }elseif($descricaoEmocao->descricao == 'medo'){
            $numeroArquivo = rand(1, 13);
        }
        //

        return view ('admin.producao.edit',[
            'producao' => $producao,
            'paciente' => $paciente,
            'emocao' => $emocao,
            'descricaoEmocao' => $descricaoEmocao,
            'numeroArquivo' => $numeroArquivo
        ]);
    }

    public function update(Request $request, $id, $emocao){
        $producao = Producao::where('id', $id)->first();

        if(!$producao)
            return redirect()->back();

        $probabilidade = ProducaoProbabilidade::where('producao_id', $id)
                            ->where('emocao', $emocao)
                            ->orderBy('valor', 'desc')
                            ->first();

        $producao['resposta'] = $probabilidade->valor;        

        $producao->save();

        return redirect()
                    ->route('producao.sucesso');
    }

    public function index($id, Paciente $paciente){
        if($id == 0){
            $pacientes = null;
        }else{
            $dataForm = ["id" => $id];
            $pacientes = $paciente->searchPacienteProducao($dataForm);
        }

        return view ('admin.producao.index', compact('pacientes'));
    }

    public function search(Request $request, Producao $producao){
        $dataForm = $request->except('_token');

        $producoes = $producao->search($dataForm);

        return view ('admin.producao.list', compact('producoes', 'dataForm'));
    }

    public function list(){
        $producoes = Producao::paginate(10);
        
        return view ('admin.producao.list', compact('producoes'));
    }

    public function sucesso(){
        return view ('admin.producao.sucesso');
    }

    public function searchPaciente(Request $request, Paciente $paciente){
        $dataForm = $request->except('_token');

        $pacientes = $paciente->searchPacienteProducao($dataForm);

        return view ('admin.producao.index', compact('pacientes', 'dataForm'));
    }

    public function storeProducaoProbabilidade(Request $request){
        $data = json_decode($request->getContent(), true);

        foreach($data as $key => $value){
            if($key == 'id'){
                $idProducao = $value;
            }elseif($key == 'emocao'){
                $idEmocao = $value;
            }
        }

        foreach($data as $key => $value){
            if($idEmocao == 1){
                if($key == 'sadness'){
                    $valorEmocao = $value;
                }
            }elseif($idEmocao == 2){
                if($key == 'joy'){
                    $valorEmocao = $value;
                }
            }elseif($idEmocao == 3){
                if($key == 'anger'){
                    $valorEmocao = $value;
                }
            }elseif($idEmocao == 4){
                if($key == 'disgust'){
                    $valorEmocao = $value;
                }
            }elseif($idEmocao == 5){
                if($key == 'surprise'){
                    $valorEmocao = $value;
                }
            }elseif($idEmocao == 6){
                if($key == 'fear'){
                    $valorEmocao = $value;
                }
            }            
        }
                
        ProducaoProbabilidade::create([
            'producao_id' => $idProducao,
            'emocao' => $idEmocao,
            'valor' => $valorEmocao
        ]);

        echo json_encode($idProducao.';'.$idEmocao.';'.$valorEmocao);
    }

    public function iniciarTeste($id){
        $paciente = Paciente::where('id', $id)->first();
        if(!$paciente)
            return redirect()->back();

        if(!(is_null(Producao::where('paciente_id', $id)->first()))){
            $producao = Producao::where('ativo', 1)->where('paciente_id', $id)->first();
            $producao['ativo'] = 0;
            $producao->save();
        }

        Producao::create([
            'paciente_id' => $id,
            'ativo' => 1
        ]);

        return redirect()
                    ->route('producao.index', [$id]);
    }

    public function confirmacao($id){

        $producao = Producao::where('id', $id)->first();
        if(!$producao)
            return redirect()->back();

        $paciente = Paciente::where('id', $producao->paciente_id)->first();

        return view ('admin.producao.confirmacao',[
            'producao' => $producao,
            'paciente' => $paciente
        ]);

    }

    public function updateIntro(StoreUpdateProducaoRequest $request, $id){

        $producao = Producao::where('id', $id)->first();

        if(!$producao)
            return redirect()->back();

        $data = $request->all();

        $producao['introducao'] = $data['introducao'];

        $producao->save();

        return redirect()
                    ->route('producao.sucesso');        

    }
}
