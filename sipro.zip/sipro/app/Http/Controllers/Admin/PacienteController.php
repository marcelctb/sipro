<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\StoreUpdatePacienteRequest;
use App\Http\Controllers\Controller;
use App\Models\Paciente;
use App\Models\Identificacao;
use App\Models\Producao;

class PacienteController extends Controller
{
    //
    public function create(Paciente $paciente){

        $sexos = $paciente->sexo();
        $com_esquizofrenias = $paciente->com_esquizofrenia();

        return view ('admin.paciente.create', compact('sexos', 'com_esquizofrenias'));
    }

    public function store(StoreUpdatePacienteRequest $request){

        $data = $request->all();

        $id = auth()->user()->id;
        $data['user_id'] = $id;
                
        $store = Paciente::create($data);

        if($store)
            return redirect()
                        ->route('paciente.create')
                        ->with('success', 'Sucesso ao cadastrar!');

        return redirect()
                    ->back()
                    ->with('error', 'Falha ao cadastrar.');
    }

    public function edit($id){

        $paciente = Paciente::where('id', $id)->first();

        $sexos = $paciente->sexo();
        $com_esquizofrenias = $paciente->com_esquizofrenia();

        if(!$paciente)
            return redirect()->back();

        return view ('admin.paciente.edit',[
            'paciente' => $paciente
        ], compact('sexos', 'com_esquizofrenias'));
    }

    public function update(StoreUpdatePacienteRequest $request, $id){

        $paciente = Paciente::where('id', $id)->first();

        if(!$paciente)
            return redirect()->back();

        $data = $request->all();

        $id = auth()->user()->id;
        $data['user_id'] = $id;

        $update = $paciente->update($data);

        if($update)
            return redirect()
                        ->route('paciente.edit', [$paciente])
                        ->with('success', 'Sucesso ao atualizar!');

        return redirect()
                    ->back()
                    ->with('error', 'Falha ao atualizar.');
    }

    public function index(Paciente $paciente){
        $pacientes = Paciente::paginate(10);

        $sexos = $paciente->sexo();
        $com_esquizofrenias = $paciente->com_esquizofrenia();
        
        return view ('admin.paciente.index', compact('pacientes', 'sexos', 'com_esquizofrenias'));
    }

    public function search(Request $request, Paciente $paciente){
        $dataForm = $request->except('_token');

        $pacientes = $paciente->search($dataForm);

        $sexos = $paciente->sexo();
        $com_esquizofrenias = $paciente->com_esquizofrenia();

        return view ('admin.paciente.index', compact('pacientes', 'sexos', 'com_esquizofrenias', 'dataForm'));
    }

    public function destroy(Request $request){
        $paciente = Paciente::where('id', $request->tabela_id)->first();

        $identificacao = Identificacao::where('paciente_id', $request->tabela_id)->first();
        $producao = Producao::where('paciente_id', $request->tabela_id)->first();

        if(is_null($identificacao) && is_null($producao)){

            $delete = $paciente->delete();

            if($delete)
                return redirect()
                            ->route('paciente.index')
                            ->with('success', 'Sucesso ao excluir!');

            return redirect()
                        ->back()
                        ->with('error', 'Falha ao excluir.');
        }else{
            return redirect()
                        ->back()
                        ->with('error', 'Paciente possui um ou mais treinamentos relacionados.');
        }
    }
}
