<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\StoreUpdateUserRequest;
use App\Http\Controllers\Controller;
use App\User;
use App\Models\Paciente;

class UserController extends Controller
{
    //
    public function create(User $user){

        $types = $user->type();

        return view ('admin.profile.create', compact('types'));
    }

    public function store(StoreUpdateUserRequest $request){

        $data = $request->all();
        
        if(!(is_null($data['password'])))
            $data['password'] = bcrypt($data['password']);
        else
            unset($data['password']);

        $store = User::create($data);

        if($store)
            return redirect()
                        ->route('profile.create')
                        ->with('success', 'Sucesso ao cadastrar!');

        return redirect()
                    ->back()
                    ->with('error', 'Falha ao cadastrar.');
    }

    public function edit($id){

        $user = User::where('id', $id)->first();

        $types = $user->type();
        
        if(auth()->user()->type != 'A'){
            foreach($user->type() as $k => $v){
                if($k == 'A'){
                    unset($types[$k]);                    
                }
            }
        }

        if(!$user)
            return redirect()->back();
        
        return view ('admin.profile.edit',[
            'user' => $user
        ], compact('types'));
    }

    public function update(StoreUpdateUserRequest $request, $id){

        $user = User::where('id', $id)->first();

        if(!$user)
            return redirect()->back();

        $data = $request->all();

        if(!(is_null($data['password'])))
            $data['password'] = bcrypt($data['password']);
        else
            unset($data['password']);
        
        $update = $user->update($data);

        if($update)
            return redirect()
                        ->route('profile.edit', [$user])
                        ->with('success', 'Sucesso ao atualizar!');

        return redirect()
                    ->back()
                    ->with('error', 'Falha ao atualizar.');
    }

    public function index(User $user){
        if(auth()->user()->type == 'A'){
            $users = User::paginate(10);
            $types = $user->type();
        }else{
            $users = User::where('id', auth()->user()->id)->get();
            $types = null;
        }        
        
        return view ('admin.profile.index', compact('users', 'types'));
    }

    public function search(Request $request, User $user){
        $dataForm = $request->except('_token');

        $users = $user->search($dataForm);

        $types = $user->type();

        return view ('admin.profile.index', compact('users', 'types', 'dataForm'));
    }

    public function destroy(Request $request){
        $user = User::where('id', $request->tabela_id)->first();

        $paciente = Paciente::where('user_id', $request->tabela_id)->first();

        if(is_null($paciente)){

            $delete = $user->delete();

            if($delete)
                return redirect()
                            ->route('profile.index')
                            ->with('success', 'Sucesso ao excluir!');

            return redirect()
                        ->back()
                        ->with('error', 'Falha ao excluir.');
        }else{
            return redirect()
                        ->back()
                        ->with('error', 'Perfil possui um ou mais pacientes relacionados.');
        }
    }
}
