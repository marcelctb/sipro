<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Models\Paciente;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'type',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function type($type = null){
        $types = [
            'A' => 'Administrador',
            'B' => 'Básico',
        ];

        if (!$type)
            return $types;

        return $types[$type];
    }

    public function search(Array $data){
        return $this->where(function ($query) use ($data){
            if(isset($data['name']))
                $query->where('name', 'like', '%' . $data['name'] . '%');

            if(isset($data['email']))
                $query->where('email', 'like', '%' . $data['email'] . '%');

            if(isset($data['type']))
                $query->where('type', $data['type']);
        })
        ->paginate(10);
    }
}
