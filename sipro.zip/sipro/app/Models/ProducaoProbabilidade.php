<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProducaoProbabilidade extends Model
{
    //
    protected $fillable = [
        'producao_id', 'emocao', 'valor',
    ];

    public $timestamps = false;
}
