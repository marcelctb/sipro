<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Emocao extends Model
{
    //
    protected $table = 'emocoes';

    protected $fillable = [
        'descricao'
    ];

    public $timestamps = false;
}
