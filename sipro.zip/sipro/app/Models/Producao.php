<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Paciente;

class Producao extends Model
{
    //
    protected $table = 'producoes';

    protected $fillable = [
        'paciente_id', 'resposta', 'emocao',
    ];

    public $timestamps = false;

    public function search(Array $data){
        return $this->where(function ($query) use ($data){
            if(isset($data['paciente']))
                $query->where('pacientes.nome', 'like', '%' . $data['paciente'] . '%');
        })
        ->join('pacientes', 'pacientes.id', '=', 'producoes.paciente_id')
        ->paginate(10);
    }

    public function paciente(){
        return $this->belongsTo(Paciente::class);
    }
}
