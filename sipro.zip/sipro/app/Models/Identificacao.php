<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Paciente;

class Identificacao extends Model
{
    //
    protected $table = 'identificacoes';

    protected $fillable = [
        'paciente_id', 'modulo',
        'resposta', 'tipo', 'emocao', 'tempo'
    ];

    public $timestamps = false;

    public function search(Array $data){
        return $this->where(function ($query) use ($data){
            if(isset($data['paciente']))
                $query->where('pacientes.nome', 'like', '%' . $data['paciente'] . '%');
        })
        ->join('pacientes', 'pacientes.id', '=', 'identificacoes.paciente_id')
        ->paginate(10);
    }

    public function paciente(){
        return $this->belongsTo(Paciente::class);
    }
}
