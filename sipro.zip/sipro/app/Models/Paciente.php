<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Identificacao;
use App\Models\Producao;

class Paciente extends Model
{
    //
    protected $fillable = [
        'nome', 'data_nasc', 'sexo', 'com_esquizofrenia', 'user_id',
    ];

    public $timestamps = false;

    public function sexo($sexo = null){
        $sexos = [
            'F' => 'Feminino',
            'M' => 'Masculino',
        ];

        if (!$sexo)
            return $sexos;

        return $sexos[$sexo];
    }

    public function com_esquizofrenia($com_esquizofrenia = null){
        $com_esquizofrenias = [
            'S' => 'Sim',
            'N' => 'Não',
        ];

        if (!$com_esquizofrenia)
            return $com_esquizofrenias;

        return $com_esquizofrenias[$com_esquizofrenia];
    }

    public function search(Array $data){
        return $this->where(function ($query) use ($data){
            if(isset($data['id']))
                $query->where('id', $data['id']);

            if(isset($data['nome']))
                $query->where('nome', 'like', '%' . $data['nome'] . '%');

            if(isset($data['data_nasc']))
                $query->where('data_nasc', $data['data_nasc']);

            if(isset($data['sexo']))
                $query->where('sexo', $data['sexo']);

            if(isset($data['user_id']))
                $query->where('user_id', $data['user_id']);
        })
        ->paginate(10);
    }

    public function searchPacienteIdentificacao(Array $data){
        return $this->where(function ($query) use ($data){
            if(isset($data['id']))
                $query->where('pacientes.id', $data['id']);

            if(isset($data['nome']))
                $query->where('pacientes.nome', 'like', '%' . $data['nome'] . '%');
        })
        ->orderBy('pacientes.id')
        ->paginate(10, array('pacientes.id', 
                             'pacientes.nome'));
    }

    public function searchPacienteProducao(Array $data){
        return $this->where(function ($query) use ($data){
            if(isset($data['id']))
                $query->where('pacientes.id', $data['id']);

            if(isset($data['nome']))
                $query->where('pacientes.nome', 'like', '%' . $data['nome'] . '%');
        })
        ->orderBy('pacientes.id')
        ->paginate(10, array('pacientes.id', 
                             'pacientes.nome'));
    }
}
