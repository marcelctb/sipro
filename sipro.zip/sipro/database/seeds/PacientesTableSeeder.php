<?php

use Illuminate\Database\Seeder;
use App\Models\Paciente;

class PacientesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Paciente::create(
            [
                'user_id' => ,
                'nome' => '',
                'data_nasc' => '',
                'sexo' => '',
                'com_esquizofrenia' => '',
            ],
        );
    }
}
