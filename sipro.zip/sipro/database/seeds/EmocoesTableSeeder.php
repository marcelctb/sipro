<?php

use Illuminate\Database\Seeder;
use App\Models\Emocao;

class EmocoesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Emocao::create(
            [
                'id' => 1,
                'descricao' => 'tristeza',
            ],
        );
        Emocao::create(
            [
                'id' => 2,
                'descricao' => 'alegria',
            ],
        );
        Emocao::create(
            [
                'id' => 3,
                'descricao' => 'raiva',
            ],
        );
        Emocao::create(
            [
                'id' => 4,
                'descricao' => 'nojo',
            ],
        );
        Emocao::create(
            [
                'id' => 5,
                'descricao' => 'surpresa',
            ],
        );
        Emocao::create(
            [
                'id' => 6,
                'descricao' => 'medo',
            ],
        );
    }
}
