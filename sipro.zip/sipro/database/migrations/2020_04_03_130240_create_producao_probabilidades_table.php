<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProducaoProbabilidadesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('producao_probabilidades', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('producao_id')->unsigned();
            $table->foreign('producao_id')->references('id')->on('producoes');
            $table->integer('emocao');
            $table->double('valor');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('producao_probabilidades');
    }
}
