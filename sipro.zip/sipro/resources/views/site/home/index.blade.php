<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>SIPRO</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .subtitle {
                font-size: 24px;
            }

            .ufsc {
                height: 97px;
                width: 70px; 
            }

            .ufpr {
                height: 71px;
                width: 110px;  
            }

            .fator_humano {
                height: 75px;
                width: 270px;  
            }

            .imago {
                height: 95px;
                width: 270px;   
            }

            #thumbs {   
                height: 100%;
                text-align: justify;
                -ms-text-justify: distribute-all-lines;
                text-justify: distribute-all-lines;                
                vertical-align: middle;
            }

            .stretch {
                width: 100%;
                display: inline-block;
                font-size: 0;
                line-height: 0;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ route('admin.home') }}">Home</a>                        
                    @else
                        <a href="{{ route('login') }}">Login</a>                        
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    SIPRO
                </div>

                <div class="subtitle m-b-md">
                    Sistema de Identificação e Produção de Expressões Faciais para Pessoas com Esquizofrenia
                </div>

                <div id="thumbs">
                    <img src="{{ asset('images/logo/ufsc.png') }}" class="ufsc">
                    <img src="{{ asset('images/logo/ufpr.png') }}" class="ufpr">
                    <img src="{{ asset('images/logo/fator_humano.png') }}" class="fator_humano">
                    <img src="{{ asset('images/logo/imago.png') }}" class="imago">
                    <span class="stretch"></span>
                </div>
            </div>
        </div>
    </body>
</html>
