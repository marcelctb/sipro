@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Perfil</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            @if(auth()->user()->type == 'A')
            <form action="{{ route('profile.search') }}" method="POST" class="form form-inline">
                {!! csrf_field() !!}
                <input type="text" name="name" class="form-control" placeholder="Nome">
                <input type="email" name="email" class="form-control" placeholder="E-mail">
                <select name="type" class="form-control">
                    <option value="">-- Selecione o Tipo --</value>
                    @foreach ($types as $key => $type)
                        <option value="{{ $key }}">{{ $type }}</value>
                    @endforeach
                </select>

                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Pesquisar</button>
            </form>
            @endif
        </div>

        @include('admin.includes.alerts')

        <div class="box-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Tipo</th>
                        <th>Opções</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users as $user)
                        <tr>
                            <td>{{ $user->id }}</td>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ $user->type($user->type) }}</td>
                            <td>
                                <a class="fa fa-edit" href="{{ route('profile.edit', $user->id) }}"></a>
                                @if(auth()->user()->id != $user->id)
                                    <a class="fa fa-trash" data-tabelaid="{{ $user->id }}" data-toggle="modal" data-target="#delete"></a>
                                @endif
                            </td>
                        </tr>
                    @empty
                    @endforelse
                </tbody>
            </table>
            @if(auth()->user()->type == 'A')
                <a href="{{ route('profile.create') }}" class="btn btn-primary"><i class="fa fa-file-alt"></i> Cadastrar</a>            
                @if(isset($dataForm))
                    {{ $users->appends($dataForm)->links() }}
                @else
                    {{ $users->links() }}
                @endif
            @endif
        </div>
    </div>

    <!-- fim lista -->

    <!-- modal -->
    <div class="modal modal-danger fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title text-center" id="myModalLabel">Confirmação</h4>
			</div>
			<form action="{{ route('profile.destroy', 'excluir') }}" method="POST">
				{{ method_field('delete') }}
				{{ csrf_field() }}
				<div class="modal-body">
					<input type="hidden" name="tabela_id" id="tabela_id" value="">
                    <p class="text-center">Tem certeza que deseja fazer a exclusão?</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Fechar</button>
					<button type="submit" class="btn btn-primary"><i class="fa fa-trash"></i> Excluir</button>
				</div>
			</form>
		</div>
	</div>
    </div>

    <!-- arquivos js para modal -->
    @include('admin.includes.jquery')
    @include('admin.includes.deletejs')    
    <!--  -->

    <!-- modal -->

@stop