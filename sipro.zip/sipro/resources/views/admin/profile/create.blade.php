@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Perfil</h1>
@stop

@section('content')
    
    <!-- inicio cadastro -->

    <div class="box">
        <div class="box-header">
            <a class="fa fa-backward" href="{{ route('profile.index') }}"></a>            
        </div>

        @include('admin.includes.alerts')
        @include('admin.includes.validators')

        <div class="box-body">
            <form action="{{ route('profile.store') }}" method="POST" style="width: 25%;">
                @include('admin.profile._partials.form')                
            </form>
        </div>
    </div>

    <!-- fim cadastro -->

@stop