{!! csrf_field() !!}
<div class="form-group">
    <label for="name">Nome</label>
    <input type="text" value="{{ $user->name ?? old('name') }}" name="name" placeholder="Nome" class="form-control">
</div>
<div class="form-group">
    <label for="email">E-mail</label>
    <input type="email" value="{{ $user->email ?? old('email') }}" name="email" placeholder="E-mail" class="form-control">
</div>
<div class="form-group">
    <label for="password">Senha</label>
    <input type="password" name="password" placeholder="Senha" class="form-control">
</div>
<div class="form-group">
    <label for="type">Tipo</label>
    <select name="type" class="form-control">
        <option value="">-- Selecione --</value>
            @foreach ($types as $key => $type)
                @if(isset($user->type))
                    @if($user->type == $key)
                        <option value="{{ $key }}" selected>{{ $type }}</value>
                    @else
                        <option value="{{ $key }}">{{ $type }}</value>
                    @endif
                @else
                    <option value="{{ $key }}" {{ (old('type') == $key ? 'selected':'') }}>{{ $type }}</option>
                @endif
            @endforeach
    </select>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-info"><i class="fa fa-arrow-alt-circle-up"></i> Enviar</button>
</div>