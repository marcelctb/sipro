@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Produção</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            <form action="{{ route('producao.search') }}" method="POST" class="form form-inline">
                {!! csrf_field() !!}
                <input type="text" name="paciente" class="form-control" placeholder="Nome">
                
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Pesquisar</button>
            </form>
        </div>

        @include('admin.includes.alerts')

        <div class="box-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Resposta</th>
                        <th>Emoção</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($producoes as $producao)
                        <tr>
                            <td>{{ $producao->id }}</td>
                            <td>{{ $producao->paciente()->get()->first()->nome }}</td>
                            <td>{{ $producao->resposta }}</td>                            
                            @if($producao->emocao == 1)
                                <td>Tristeza</td>
                            @elseif($producao->emocao == 2)
                                <td>Alegria</td>
                            @elseif($producao->emocao == 3)
                                <td>Raiva</td>
                            @elseif($producao->emocao == 4)
                                <td>Nojo</td>
                            @elseif($producao->emocao == 5)
                                <td>Surpresa</td>
                            @elseif($producao->emocao == 6)
                                <td>Medo</td>
                            @endif
                        </tr>
                    @empty
                    @endforelse
                </tbody>
            </table>
            @if(isset($dataForm))
                {{ $producoes->appends($dataForm)->links() }}
            @else
                {{ $producoes->links() }}
            @endif
        </div>
    </div>

    <!-- fim lista -->

@stop