@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Produção</h1>
@stop

@section('content')
    
    <!-- inicio cadastro -->

    <div class="box">
        <!--<div class="box-header">
            <a class="fa fa-backward" href="{{ route('producao.index', ['id' => 0]) }}"></a>            
        </div>-->

        @include('admin.includes.alerts')
        @include('admin.includes.validators')

        <div class="box-body">
            @include('admin.producao._partials.form')                        
        </div>
    </div>

    <!-- fim cadastro -->

    @include('admin.includes.jquery')
    @include('admin.includes.producaojs')

@stop