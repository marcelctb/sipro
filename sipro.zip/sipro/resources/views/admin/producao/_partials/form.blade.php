<div class="form-group">
    <!--<label for="nome">Nome</label>
    <div name="nome">{{ $paciente->nome }}</div>
    <br>-->
    <label for="ouca">Ouça o texto</label>
    <div name="nome">
        <audio controls>        
            <source src="{{ asset('audios/producao/'.$descricaoEmocao->descricao.'.mp3') }}" type="audio/mpeg">        
        </audio>
    </div>
</div>
<div class="form-group">
    <!--<label for="instrucao">Instruções</label>-->
    <div name="instrucao">
        <h3>
            <u>Instruções</u>: Procure reproduzir a emoção relacionada ao sentimento <b>{{ $descricaoEmocao->descricao }}</b>, que está sendo mostrado na figura a seguir. Tente pensar em algo que te traga esta emoção.
        </h3>    
    </div>
</div>
<div class="form-group">
    <table>
        <tr>
            <td rowspan="2"><div><img src="{{ asset('images/cafe/'.$descricaoEmocao->descricao.'/01/'.$numeroArquivo.'.png') }}" width="297" height="381" class="cafe"></div></td>
            <!--<td></td>-->            
        </tr>        
        <tr> 
            <td class="radioEmocoes">
                <!--<div id="affdex_elements" class="cafe"></div>-->
                <div id="affdex_elements"></div>    
            </td>
        </tr>
    </table>
</div>
<div class="form-group">
    <button id="start" class="btn btn-info" onclick="onStart()"><i class="fa fa-play-circle"></i> Iniciar</button>

    <form action="{{ route('producao.update', ['id' => $producao->id, 'emocao' => $emocao]) }}" method="POST">
        {{ method_field('PUT') }}
        {!! csrf_field() !!}
        <button id="continue" type="submit" class="btn btn-info"><i class="fa fa-arrow-alt-circle-right"></i> Continuar</button>
    </form>
    <!--<label for="timer">Tempo</label>-->
    <div id="results"></div>
</div>