{!! csrf_field() !!}
<div class="form-group">
    <!--<label for="nome">Nome</label>
    <div name="nome">{{ $paciente->nome }}</div>-->
</div>
<div class="form-group">
    <label for="confirmacao">Você entendeu o objetivo do treinamento?</label>
    <div name="confirmacao">
        <input type="radio" name="introducao" value="0"> Não<br>
        <input type="radio" name="introducao" value="100"> Sim
    </div>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-info"><i class="fa fa-arrow-alt-circle-up"></i> Enviar</button>
</div>