@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Produção</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            <a class="fa fa-backward" href="{{ route('producao.index', ['id' => 0]) }}"></a>
        </div>

        @include('admin.includes.alerts')
        @include('admin.includes.validators')

        <div class="box-body">
            <form action="{{ route('producao.updateIntro', ['id' => $producao->id]) }}" method="POST">
                {{ method_field('PUT') }}
                @include('admin.producao._partials.formintro')
            </form>
        </div>
    </div>

    <!-- fim lista -->

@stop