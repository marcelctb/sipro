@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Paciente</h1>
@stop

@section('content')
    
    <!-- inicio cadastro -->

    <div class="box">
        <div class="box-header">
            <a class="fa fa-backward" href="{{ route('paciente.index') }}"></a>            
        </div>

        @include('admin.includes.alerts')
        @include('admin.includes.validators')

        <div class="box-body">
            <form action="{{ route('paciente.update', $paciente->id) }}" method="POST" style="width: 25%;">
                {{ method_field('PUT') }}
                @include('admin.paciente._partials.form')
            </form>
        </div>
    </div>

    <!-- fim cadastro -->

@stop