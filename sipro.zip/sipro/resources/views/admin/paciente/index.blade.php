@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Paciente</h1>    
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            <form action="{{ route('paciente.search') }}" method="POST" class="form form-inline">
                {!! csrf_field() !!}
                <input type="text" name="nome" class="form-control" placeholder="Nome">
                <input type="date" name="data_nasc" class="form-control" placeholder="Data Nasc.">
                <input type="text" name="user_id" class="form-control" placeholder="Perfil">
                <select name="sexo" class="form-control">
                    <option value="">-- Selecione o Sexo --</value>
                    @foreach ($sexos as $key => $sexo)
                        <option value="{{ $key }}">{{ $sexo }}</value>
                    @endforeach
                </select>

                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Pesquisar</button>
            </form>
        </div>

        @include('admin.includes.alerts')

        <div class="box-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Data Nasc.</th>
                        <th>Sexo</th>
                        <th>Pessoa com Esquizofrenia?</th>
                        <th>Perfil</th>
                        <th>Opções</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($pacientes as $paciente)
                        <tr>
                            <td>{{ $paciente->id }}</td>
                            <td>{{ $paciente->nome }}</td>
                            <td>{{ date('d/m/Y', strtotime($paciente->data_nasc)) }}</td>
                            <td>{{ $paciente->sexo }}</td>
                            <td>{{ $paciente->com_esquizofrenia }}</td>
                            <td>{{ $paciente->user_id }}</td>
                            <td>
                                <a class="fa fa-edit" href="{{ route('paciente.edit', $paciente->id) }}"></a>
                                <a class="fa fa-trash" data-tabelaid="{{ $paciente->id }}" data-toggle="modal" data-target="#delete"></a>
                            </td>
                        </tr>
                    @empty
                    @endforelse
                </tbody>
            </table>
            <a href="{{ route('paciente.create') }}" class="btn btn-primary"><i class="fa fa-file-alt"></i> Cadastrar</a>
            @if(isset($dataForm))
                {{ $pacientes->appends($dataForm)->links() }}
            @else
                {{ $pacientes->links() }}
            @endif
        </div>
    </div>

    <!-- fim lista -->

    <!-- modal -->
    <div class="modal modal-danger fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title text-center" id="myModalLabel">Confirmação</h4>
			</div>
			<form action="{{ route('paciente.destroy', 'excluir') }}" method="POST">
				{{ method_field('delete') }}
				{{ csrf_field() }}
				<div class="modal-body">
					<input type="hidden" name="tabela_id" id="tabela_id" value="">
                    <p class="text-center">Tem certeza que deseja fazer a exclusão?</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Fechar</button>
					<button type="submit" class="btn btn-primary"><i class="fa fa-trash"></i> Excluir</button>
				</div>
			</form>
		</div>
	</div>
    </div>

    <!-- arquivos js para modal -->
    @include('admin.includes.jquery')
    @include('admin.includes.deletejs')    
    <!--  -->
    
    <!-- modal -->

@stop