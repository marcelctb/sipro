{!! csrf_field() !!}
<div class="form-group">
    <label for="nome">Nome</label>
    <input type="text" value="{{ $paciente->nome ?? old('nome') }}" name="nome" placeholder="Nome" class="form-control">
</div>
<div class="form-group">
    <label for="data_nasc">Data Nasc.</label>
    <input type="date" value="{{ $paciente->data_nasc ?? old('data_nasc') }}" name="data_nasc" placeholder="Data Nasc." class="form-control">
</div>
<div class="form-group">
    <label for="sexo">Sexo</label>
    <select name="sexo" class="form-control">
        <option value="">-- Selecione --</value>
            @foreach ($sexos as $key => $sexo)
                @if(isset($paciente->sexo))
                    @if($paciente->sexo == $key)
                        <option value="{{ $key }}" selected>{{ $sexo }}</value>
                    @else
                        <option value="{{ $key }}">{{ $sexo }}</value>
                    @endif
                @else
                    <option value="{{ $key }}" {{ (old('sexo') == $key ? 'selected':'') }}>{{ $sexo }}</option>
                @endif
            @endforeach
    </select>
</div>
<div class="form-group">
    <label for="com_esquizofrenia">É pessoa com esquizofrenia?</label>
    <select name="com_esquizofrenia" class="form-control">
        <option value="">-- Selecione --</value>
            @foreach ($com_esquizofrenias as $key => $com_esquizofrenia)
                @if(isset($paciente->com_esquizofrenia))
                    @if($paciente->com_esquizofrenia == $key)
                        <option value="{{ $key }}" selected>{{ $com_esquizofrenia }}</value>
                    @else
                        <option value="{{ $key }}">{{ $com_esquizofrenia }}</value>
                    @endif
                @else
                    <option value="{{ $key }}" {{ (old('com_esquizofrenia') == $key ? 'selected':'') }}>{{ $com_esquizofrenia }}</option>
                @endif
            @endforeach
    </select>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-info"><i class="fa fa-arrow-alt-circle-up"></i> Enviar</button>
</div>