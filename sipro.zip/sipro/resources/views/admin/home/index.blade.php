@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Home</h1>
@stop

@section('content')
    <p>Bem-vindo(a) ao sistema!</p>
@stop