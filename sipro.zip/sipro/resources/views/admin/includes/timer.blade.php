<script>
var startTime = 0;
var start = 0;
var end = 0;
var diff = 0;
var timerID = 0;
function chrono(){
	end = new Date();
	diff = end - start;
	diff = new Date(diff);
	var msec = diff.getMilliseconds();
	var sec = diff.getSeconds();
	var min = diff.getMinutes();
    //var hr = diff.getHours()-1;
    var hr = 0;
    if (hr < 10){
		hr = "0" + hr;
	}
	if (min < 10){
		min = "0" + min;
	}
	if (sec < 10){
		sec = "0" + sec;
	}
	if(msec < 10){
		msec = "00" +msec;
	}
	else if(msec < 100){
		msec = "0" +msec;
	}
	document.getElementById("tempo").value = hr + ":" + min + ":" + sec + "." + msec;
	timerID = setTimeout("chrono()", 10);
}
function chronoStart(){
	//document.chronoForm.startstop.value = "stop!";
	//document.chronoForm.startstop.onclick = chronoStop;
	//document.chronoForm.reset.onclick = chronoReset;
	start = new Date();
	chrono();
}
</script>