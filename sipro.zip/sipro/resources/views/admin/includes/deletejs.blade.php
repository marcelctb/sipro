<script>
$(document).ready(function() {
    $('#delete').on('show.bs.modal', function (event){
        var button = $(event.relatedTarget);
        var tabela_id = button.data('tabelaid');
        var modal = $(this);

        modal.find('.modal-body #tabela_id').val(tabela_id);
    });
});
</script>