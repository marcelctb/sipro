@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Identificação</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            <form action="{{ route('identificacao.searchPaciente') }}" method="POST" class="form form-inline">
                {!! csrf_field() !!}
                <input type="text" name="id" class="form-control" placeholder="Id">
                <input type="text" name="nome" class="form-control" placeholder="Nome">                

                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Pesquisar</button>
            </form>
        </div>

        @include('admin.includes.alerts')

        <div class="box-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Introdução</th>
                        <th>Alegria</th>
                        <th>Tristeza</th>
                        <th>Surpresa</th>
                        <th>Raiva</th>
                        <th>Nojo</th>                        
                        <th>Medo</th>                        
                    </tr>
                </thead>
                <tbody>
                    @if(!(is_null($pacientes)))
                        @forelse($pacientes as $paciente)
                            <tr>
                                <td>{{ $paciente->id }}</td>
                                <td>{{ $paciente->nome }}</td>
                                <td>                                
                                    <a class="fa fa-edit" href="{{ route('identificacao.introducao', ['id' => $paciente->id, 'pg' => 1, 'emocao' => 0]) }}"></a>                                    
                                </td>
                                <td>
                                    <a class="fa fa-edit" href="{{ route('identificacao.emocao', ['id' => $paciente->id, 'pg' => 1, 'emocao' => 2, 'pergunta' => 'S,N,N']) }}"></a>                                                                            
                                </td>
                                <td>                                                                           
                                    <a class="fa fa-edit" href="{{ route('identificacao.emocao', ['id' => $paciente->id, 'pg' => 1, 'emocao' => 1, 'pergunta' => 'S,N,N']) }}"></a>                                    
                                </td>
                                <td>
                                    <a class="fa fa-edit" href="{{ route('identificacao.emocao', ['id' => $paciente->id, 'pg' => 1, 'emocao' => 5, 'pergunta' => 'S,N,N']) }}"></a>                                    
                                </td>                                
                                <td>
                                    <a class="fa fa-edit" href="{{ route('identificacao.emocao', ['id' => $paciente->id, 'pg' => 1, 'emocao' => 3, 'pergunta' => 'S,N,N']) }}"></a>                                    
                                </td>
                                <td>
                                    <a class="fa fa-edit" href="{{ route('identificacao.emocao', ['id' => $paciente->id, 'pg' => 1, 'emocao' => 4, 'pergunta' => 'S,N,N']) }}"></a>                                    
                                </td>                                
                                <td>
                                    <a class="fa fa-edit" href="{{ route('identificacao.emocao', ['id' => $paciente->id, 'pg' => 1, 'emocao' => 6, 'pergunta' => 'S,N,N']) }}"></a>                                    
                                </td>
                            </tr>
                        @empty
                        @endforelse
                    @endif    
                </tbody>
            </table>
            @if(!(is_null($pacientes)))
                @if(isset($dataForm))
                    {{ $pacientes->appends($dataForm)->links() }}
                @else
                    {{ $pacientes->links() }}
                @endif
            @endif
        </div>
    </div>

    <!-- fim lista -->

@stop