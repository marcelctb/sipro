@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Sucesso</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            <a class="fa fa-backward" href="{{ route('identificacao.index', ['id' => 0]) }}"></a>
        </div>

        <div class="box-body">
            <div class="form-group">
                <div name="nome"><h3>Treinamento finalizado. Agradecemos sua participação!</h3></div>
            </div>
        </div>
    </div>

    <!-- fim lista -->

@stop