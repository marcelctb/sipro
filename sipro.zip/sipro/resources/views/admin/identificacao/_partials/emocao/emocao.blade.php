@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Identificação</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            @if($pg == 1)
                <a class="fa fa-backward" href="{{ route('identificacao.index', ['id' => 0]) }}"></a>
            @else
                <a class="fa fa-backward" href="{{ route('identificacao.emocao', ['id' => $paciente->id, 'pg' => $pg - 1, 'emocao' => $emocao, 'pergunta' => $pergunta]) }}"></a>
            @endif
        </div>

        @include('admin.includes.alerts')
        @include('admin.includes.validators')
        @include('admin.includes.timer')

        <div class="box-body">
            <form action="{{ route('identificacao.updateEmocao', ['id' => $paciente->id, 'pg' => $pg + 1, 'emocao' => $emocao, 'pergunta' => $pergunta]) }}" method="POST">
                {{ method_field('PUT') }}
                {!! csrf_field() !!}
                <div class="form-group">
                    <!--<label for="nome">Nome</label>
                    <div name="nome">{{ $paciente->nome }}</div>
                    <br>-->
                    <label for="ouca">Ouça o texto</label>
                    <div name="nome">
                        <audio controls>
                            <source src="{{ asset('audios/identificacao/'.$descricaoEmocao->descricao.'/slide'.$pg.'.mp3') }}" type="audio/mpeg">
                        </audio>
                    </div>
                </div>
                <div class="form-group">
                    <div name="figura">
                        <img src="{{ asset('images/identificacao/'.$descricaoEmocao->descricao.'/Slide'.$pg.'.PNG') }}" class="apresentacao" onload="chronoStart()">
                        <input type="hidden" name="tempo" id="tempo" value="">
                        <input type="hidden" name="resposta" value="N">
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-info"><i class="fa fa-arrow-alt-circle-right"></i> Continuar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- fim lista -->

@stop