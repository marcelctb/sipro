@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Identificação</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        
        @include('admin.includes.alerts')
        @include('admin.includes.validators')
        @include('admin.includes.timer')

        <div class="box-body">
            <form action="{{ route('identificacao.updateIntroducao', ['id' => $paciente->id, 'pg' => $pg + 1, 'emocao' => $emocao]) }}" method="POST" style="width: 100%;">
                {{ method_field('PUT') }}
                @include('admin.identificacao._partials.formintro')
            </form>
        </div>
    </div>

    <!-- fim lista -->

@stop