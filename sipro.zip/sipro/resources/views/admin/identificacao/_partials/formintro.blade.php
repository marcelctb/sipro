{!! csrf_field() !!}
<div class="form-group">
    <!--<label for="nome">Nome</label>
    <div name="nome">{{ $paciente->nome }}</div>
    <br>-->
    <label for="ouca">Ouça o texto</label>
    <div name="nome">
        <audio controls>
            <source src="{{ asset('audios/identificacao/introducao/slide'.$pg.'.mp3') }}" type="audio/mpeg">
        </audio>
    </div>
</div>
<div class="form-group">
    <label for="confirmacao"><h3>Você entendeu o objetivo do treinamento?</h3></label>
    <div name="confirmacao">
        <h3><input type="radio" name="resposta" value="100"> Sim<br></h3>
        <h3><input type="radio" name="resposta" value="0"> Não</h3>
        <img src="{{ asset('images/identificacao/introducao/dot.PNG') }}" onload="chronoStart()">
        <input type="hidden" name="tempo" id="tempo" value="">
    </div>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-info"><i class="fa fa-arrow-alt-circle-up"></i> Enviar</button>
</div>