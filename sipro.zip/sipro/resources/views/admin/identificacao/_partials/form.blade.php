{!! csrf_field() !!}
<div class="form-group">
    <!--<label for="nome">Nome</label>
    <div name="nome">{{ $paciente->nome }}</div>
    <br>-->
    <label for="ouca">Ouça o texto</label>
    <div name="nome">
        <audio controls>
        @if($emocao == 1)
            <source src="{{ asset('audios/identificacao/tristeza/slide'.$pg.'.mp3') }}" type="audio/mpeg">
        @elseif($emocao == 2)
            <source src="{{ asset('audios/identificacao/alegria/slide'.$pg.'.mp3') }}" type="audio/mpeg">
        @elseif($emocao == 3)
            <source src="{{ asset('audios/identificacao/raiva/slide'.$pg.'.mp3') }}" type="audio/mpeg">
        @elseif($emocao == 4)
            <source src="{{ asset('audios/identificacao/nojo/slide'.$pg.'.mp3') }}" type="audio/mpeg">
        @elseif($emocao == 5)
            <source src="{{ asset('audios/identificacao/surpresa/slide'.$pg.'.mp3') }}" type="audio/mpeg">
        @elseif($emocao == 6)
            <source src="{{ asset('audios/identificacao/medo/slide'.$pg.'.mp3') }}" type="audio/mpeg">
        @endif    
        </audio>
    </div>
</div>
<div class="form-group">
    <!--<label for="instrucao"></label>-->
    <div name="instrucao">
        <h3>Agora, por favor responda:</h3>
    </div>
</div>
<div class="form-group">
    <table>
        <tr>
            <td rowspan="7">
                <img src="{{ asset('images/cafe/'.$descricaoEmocao->descricao.'/01/'.$numeroArquivo.'.png') }}" width="297" height="381" onload="chronoStart()">
                <input type="hidden" name="tempo" id="tempo" value="">
            </td>
            <!--<td></td>-->            
        </tr>        
        <tr> 
            <td class="radioEmocoes">
                <div name="descricao">
                    @if($emocao == 1)
                        <h3>Na imagem ao lado, esta pessoa está expressando tristeza?<br></h3>
                    @elseif($emocao == 2)
                        <h3>Na imagem ao lado, esta pessoa está expressando alegria?<br></h3>
                    @elseif($emocao == 3)
                        <h3>Na imagem ao lado, esta pessoa está expressando raiva?<br></h3>
                    @elseif($emocao == 4)
                        <h3>Na imagem ao lado, esta pessoa está expressando nojo?<br></h3>
                    @elseif($emocao == 5)
                        <h3>Na imagem ao lado, esta pessoa está expressando surpresa?<br></h3>
                    @elseif($emocao == 6)
                        <h3>Na imagem ao lado, esta pessoa está expressando medo?<br></h3>
                    @endif                    
                    <h3><input type="radio" name="resposta" value="{{ $opcaoSim }}"> Yes<br></h3>
                    <h3><input type="radio" name="resposta" value="{{ $opcaoNao }}"> No</h3>
                    <input type="hidden" name="tipo" value="{{ $emocaoTipo }}">
                </div>
            </td>
        </tr>        
    </table>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-info"><i class="fa fa-arrow-alt-circle-up"></i> Enviar</button>
</div>