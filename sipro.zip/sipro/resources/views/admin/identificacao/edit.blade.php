@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Identificação</h1>
@stop

@section('content')
    
    <!-- inicio cadastro -->

    <div class="box">
        <div class="box-header">
            <a class="fa fa-backward" href="{{ route('identificacao.index', ['id' => 0]) }}"></a>            
        </div>

        @include('admin.includes.alerts')
        @include('admin.includes.validators')

        <div class="box-body">
            <form action="{{ route('identificacao.update', ['id' => $identificacao->id, 'emocao' => $emocao]) }}" method="POST" style="width: 100%;">
                {{ method_field('PUT') }}
                @include('admin.identificacao._partials.form')
            </form>
        </div>
    </div>

    <!-- fim cadastro -->

@stop