@extends('adminlte::page')

@section('title', 'SIPRO')

@section('content_header')
    <h1>Identificação</h1>
@stop

@section('content')
    
    <!-- inicio lista -->

    <div class="box">
        <div class="box-header">
            <form action="{{ route('identificacao.search') }}" method="POST" class="form form-inline">
                {!! csrf_field() !!}
                <input type="text" name="paciente" class="form-control" placeholder="Nome">
                
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Pesquisar</button>
            </form>
        </div>

        @include('admin.includes.alerts')

        <div class="box-body">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Resposta</th>
                        <th>Tipo</th>
                        <th>Emoção</th>
                        <th>Tempo</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($identificacoes as $identificacao)
                        <tr>
                            <td>{{ $identificacao->id }}</td>
                            <td>{{ $identificacao->paciente()->get()->first()->nome }}</td>
                            <td>{{ $identificacao->resposta }}</td>
                            <td>{{ $identificacao->tipo }}</td>
                            @if($identificacao->emocao == 0)
                                <td>Introdução</td>
                            @elseif($identificacao->emocao == 1)
                                <td>Tristeza</td>
                            @elseif($identificacao->emocao == 2)
                                <td>Alegria</td>
                            @elseif($identificacao->emocao == 3)
                                <td>Raiva</td>
                            @elseif($identificacao->emocao == 4)
                                <td>Nojo</td>
                            @elseif($identificacao->emocao == 5)
                                <td>Surpresa</td>
                            @elseif($identificacao->emocao == 6)
                                <td>Medo</td>
                            @endif
                            <td>{{ \Carbon\Carbon::parse($identificacao->tempo)->format('i:s.u') }}</td>
                        </tr>
                    @empty
                    @endforelse
                </tbody>
            </table>
            @if(isset($dataForm))
                {{ $identificacoes->appends($dataForm)->links() }}
            @else
                {{ $identificacoes->links() }}
            @endif
        </div>
    </div>

    <!-- fim lista -->

@stop